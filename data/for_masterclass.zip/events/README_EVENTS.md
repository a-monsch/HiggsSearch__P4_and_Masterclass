.ig files and detailed_information are taken from the official Publications of the year 2012 Run [B,C]*.

*http://opendata.cern.ch/record/5500